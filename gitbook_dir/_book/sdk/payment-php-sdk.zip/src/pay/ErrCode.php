<?php
namespace Asen\Pay;

class ErrCode
{

    public static array $errorStrToCode = array(
        "NetworkErr"=>-10001,
        "CodeSuccess" => 8001,
        "CodeSystemFailed" => 8002,
        "CodeCheckApiKeyFailed" => 8003,
        "CodeCheckSignFailed" => 8004,
        "AppCloseErr" => 8005,
        "ParamErr" => 8006,
        "WithdrawAmountLimitErr" => 8007,
        "IdentifyNotExist" => 8008,
        "WithdrawOrderIdRepeat" => 8009,
        "WithdrawSystemError" => 8010,
        "rechargeSystemError" => 8012
    );

//$errorCodeToStr = array_flip($errorStrToCode);

    public static array $errorCodeToStr = array(
        -10001 => "NetworkErr",
        8001 => "CodeSuccess",
        8002 => "CodeSystemFailed",
        8003 => "CodeCheckApiKeyFailed",
        8004 => "CodeCheckSignFailed",
        8005 => "AppCloseErr",
        8006 => "ParamErr",
        8007 => "WithdrawAmountLimitErr",
        8008 => "IdentifyNotExist",
        8009 => "WithdrawOrderIdRepeat",
        8010 => "WithdrawSystemError",
        8011 => "rechargeSystemError",
    );


    public static function GetErrorStrByCode(int $errorCode): string
    {
        if (isset(self::$errorCodeToStr[$errorCode])) {
            return self::$errorCodeToStr[$errorCode];
        } else {
            return "";
        }

    }


}




