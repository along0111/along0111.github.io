<?php
namespace Asen\Pay;

const RECHARGE_CALLBACK = "recharge_callback";

class RechargeCallback {

    //回调主题
    public  string $subject = RECHARGE_CALLBACK;
    //用户唯一id
    public  string $identify;
    //暂时可忽略 链类型
    public  int $chain_type;
    //暂时可忽略 合约类型
    public  int $contract_type;
    //重试ID 用以追踪回调服务
    public  string $retry_id;
    //本地订单ID，用以追踪订单
    public  string $order_id;
    //区块订单交易HASH
    public  string  $transaction_id;
    //充值金额
    public  float  $amount;
    //签名
    public  string  $signature;
    //原始数据
    protected array $originalData;

    protected bool $verifiedSignature = false;

    public function GetOriginalData(): array
    {
        return $this->originalData;
    }

    //签名是否验证通过
    public function checkSignature(): bool
    {
        return $this->verifiedSignature;
    }

    // 响应标准化，商户可自行响应
    public function ResponseToPayGateWay()
    {
        if($this->checkSignature()){
            echo json_encode(array("code"=>1));
            exit(1);
        }else{
            echo json_encode(array("code"=>-1));
            exit(0);
        }
    }

    public static function newRechargeCallback(bool $signatureVerified,$originalData = array(),$identify = "", $chain_type = 0, $contract_type = 0, $retry_id = "", $order_id = "", $transaction_id = "", $amount = 0.0, $signature=""): \Asen\Pay\RechargeCallback
    {

        $object = new RechargeCallback();

        $object->identify = $identify;
        $object->chain_type = $chain_type;
        $object->contract_type = $contract_type;
        $object->retry_id = $retry_id;
        $object->order_id = $order_id;
        $object->transaction_id = $transaction_id;
        $object->amount = $amount;
        $object->signature = $signature;
        $object->verifiedSignature = $signatureVerified;
        $object->originalData = $originalData;

        return $object;
    }

}
