<?php
namespace Asen\Pay;

const WITHDRAW_CALLBACK = "withdraw_callback";

class WithdrawCallback {
    //回调主题
    public  string $subject = WITHDRAW_CALLBACK;
    //用户唯一ID
    public  string $identify;
    //链类型
    public  int $chain_type;
    //合约类型
    public  int $contract_type;
    //重试ID 用以追踪回调服务
    public  string $retry_id;
    //本地订单ID，用以追踪订单
    public  string $order_id;
    //区块订单交易HASH
    public  string  $transaction_id;
    //充值金额
    public  float  $amount;
    //签名
    public  string  $signature;
    //原始数据
    protected array $originalData;
    protected bool $verifiedSignature = false;

    public function GetOriginalData(): array
    {
        return $this->originalData;
    }

    //验证签名
    public function checkSignature(): bool
    {
        return $this->verifiedSignature;
    }

    // 响应标准化，商户可自行响应
    public function ResponseToPayGateWay()
    {
        if($this->checkSignature()){
            echo json_encode(array("code"=>1));
        }else{
            echo json_encode(array("code"=>-1));
        }
    }
    public static function newWithdrawCallback(bool $signatureVerified,$originalData = array(),$identify = "", $chain_type = 0, $contract_type = 0, $retry_id = "", $order_id = "", $transaction_id = "", $amount = 0.0, $signature=""): \Asen\Pay\WithdrawCallback
    {

        $object = new WithdrawCallback();
        $object->identify = $identify;
        $object->chain_type = $chain_type;
        $object->contract_type = $contract_type;
        $object->retry_id = $retry_id;
        $object->order_id = $order_id;
        $object->transaction_id = $transaction_id;
        $object->amount = $amount;
        $object->signature = $signature;
        $object->verifiedSignature = $signatureVerified;
        $object->originalData = $originalData;

        return $object;
    }

}
