<?php

namespace Asen\Pay;

use const Asen\Pay\CodeSuccess;
class WithdrawResponse {
    //暂时可忽略 链类型
    public  int $code;

    //支付网关反馈的请求ID
    public string $request_id;

    public function CheckIsSuccess():bool
    {
        if($this->code == CodeSuccess){
            return true;
        }
        return false;
    }
    public static function newWithdrawResponse(int $code,string $request_id):WithdrawResponse{
        $object = new WithdrawResponse();
        $object->code = $code;
        $object->request_id = $request_id;
        return $object;
    }

}

