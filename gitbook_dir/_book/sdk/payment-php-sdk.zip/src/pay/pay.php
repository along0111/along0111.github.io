<?php
namespace Asen\Pay;

use Asen\Pay\RechargeResponse;
use Asen\Pay\RechargeCallback;


const  NetworkErr = -1001;
const  CodeSuccess = 8001;
const    CodeSystemFailed = 8002;
const    CodeCheckApiKeyFailed = 8003;
const    CodeCheckSignFailed = 8004;
const    AppCloseErr = 8005;
const    ParamErr = 8006;
const    WithdrawAmountLimitErr = 8007;
const    IdentifyNotExist = 8008;
const    WithdrawOrderIdRepeat = 8009;
const    WithdrawSystemError = 8010;
const    RechargeSystemError = 8011;

class Pay{

    protected static string $endPoint;
    protected static int $appId;
    protected static string $api_key;

    protected static string $CLIENT_PRIVATE_KEY;
    protected static string $PAY_GATEWAY_PUBLIC_KEY;

    public static function SetClientPrivateKeyAndPayGatewayPublicKey(string $clientPrivateKey,string $payGateWayPublicKey)
    {
        self::$CLIENT_PRIVATE_KEY = $clientPrivateKey;
        self::$PAY_GATEWAY_PUBLIC_KEY = $payGateWayPublicKey;
    }

    public static function SetEndpoint(string $endpoint)
    {
        self::$endPoint = $endpoint;
    }

    public static function SetAppId(int $appId)
    {
        self::$appId = $appId;
    }

    public static function SetApiKey(string $appKey)
    {
        self::$api_key = $appKey;
    }

    protected static function packData(array $data):string
    {
        $signature = Signature::SignRequestData(self::$CLIENT_PRIVATE_KEY,json_encode($data,true));
        return json_encode(array(
            "app_id"=>self::$appId,
            "api_key"=>self::$api_key,
            "signature"=>$signature,
            "data"=>$data
        ),true);
    }


    public static function RechargeCallback($isTest=false,$rawPostData = ""):RechargeCallback
    {
        if(!$isTest){
            $rawPostData = file_get_contents('php://input');
        }

        if($rawPostData == ""){
            return RechargeCallback::newRechargeCallback(
                false
            );
        }
        $callbackArray = json_decode($rawPostData,true);
        if ($callbackArray["signature"] == ""){
            return RechargeCallback::newRechargeCallback(
                false,
                $callbackArray
            );
        }else{
            if(Signature::VerifyCallbackSign(self::$PAY_GATEWAY_PUBLIC_KEY,json_encode($callbackArray["data"]),$callbackArray["signature"])){
                return RechargeCallback::newRechargeCallback(
                    true,
                    $callbackArray,
                    $callbackArray["data"]["identify"],
                    $callbackArray["data"]["chain_type"],
                    $callbackArray["data"]["contract_type"],
                    $callbackArray["data"]["retry_id"],
                    $callbackArray["data"]["order_id"],
                    $callbackArray["data"]["transaction_id"],
                    $callbackArray["data"]["amount"],
                    $callbackArray["signature"],
                );

            }else{
                return RechargeCallback::newRechargeCallback(
                    false,
                    $callbackArray
                );
            }
        }
    }


    public static function WithdrawCallback($isTest=false,$rawPostData = ""):WithdrawCallback
    {
        if(!$isTest){
            $rawPostData = file_get_contents('php://input');
        }

        if($rawPostData == ""){
            return WithdrawCallback::newWithdrawCallback(
                false
            );
        }

        $callbackArray = json_decode($rawPostData,true);
        if ($callbackArray["signature"] == ""){
            return WithdrawCallback::newWithdrawCallback(
                false,
                $callbackArray
            );
        }else{
            if(Signature::VerifyCallbackSign(self::$PAY_GATEWAY_PUBLIC_KEY,json_encode($callbackArray["data"]),$callbackArray["signature"])){
                return WithdrawCallback::newWithdrawCallback(
                    true,
                    $callbackArray,
                    $callbackArray["data"]["identify"],
                    $callbackArray["data"]["chain_type"],
                    $callbackArray["data"]["contract_type"],
                    $callbackArray["data"]["retry_id"],
                    $callbackArray["data"]["order_id"],
                    $callbackArray["data"]["transaction_id"],
                    $callbackArray["data"]["amount"],
                    $callbackArray["signature"],
                );

            }else{
                return  WithdrawCallback::newWithdrawCallback(
                    false,
                    $callbackArray
                );
            }
        }
    }


    /**
     * @param string $identify 商户端用户唯一id
     * @param string $orderId 商户全局唯一订单ID
     * @param string $withdrawAddress 提现地址
     * @param float $amount 提现金额
     * @return array 请求结果
     */
    public static function RequestWithdraw(string $identify,string $orderId, string $withdrawAddress,float $amount):WithdrawResponse
    {
        $rechargeData = array(
            "identify"=>$identify,
            "order_id"=>$orderId,
            "withdraw_address"=>$withdrawAddress,
            "amount"=>$amount
        );
        $packData = self::packData($rechargeData);
        try {
            $resp = self::Request(self::$endPoint . "/withdraw",$packData);
            if(isset($resp["data"])){
                return WithdrawResponse::newWithdrawResponse($resp["code"],$resp["data"]["request_id"]);
            }else{
                return WithdrawResponse::newWithdrawResponse($resp["code"],"");
            }
        }catch (\Exception $e){
            return WithdrawResponse::newWithdrawResponse(NetworkErr,"");
        }
    }

    public static function RequestRecharge(string $identify): \Asen\Pay\RechargeResponse
    {
        $rechargeData = array(
            "identify"=>$identify,
        );
        $packData = self::packData($rechargeData);
//        $resp = self::Request(self::$endPoint . "/recharge",$packData);
//        return RechargeResponse.php::newRechargeResponse($resp["code"],$resp["data"]["address"]);

        try {
            $resp = self::Request(self::$endPoint . "/recharge",$packData);
            if(isset($resp["data"])){
                return RechargeResponse::newRechargeResponse($resp["code"],$resp["data"]["address"]);
            }else{
                return RechargeResponse::newRechargeResponse($resp["code"],"");
            }
        }catch (\Exception $e){
            return RechargeResponse::newRechargeResponse(NetworkErr,"");
        }
    }

    protected static function Request(string $uri, string $postDataJSON):array
    {
        $respStr = HttpRequest::post($uri, $postDataJSON, true);
//        var_dump($respStr);
        $resp = json_decode($respStr, true);
        if ($resp["code"] != CodeSuccess) {
            $resp["msg"] = ErrCode::GetErrorStrByCode($resp["code"]) ?? '请求失败';
        }
        return $resp;
    }
}
