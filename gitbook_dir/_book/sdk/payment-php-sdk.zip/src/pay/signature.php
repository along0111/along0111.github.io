<?php
namespace Asen\Pay;

require_once "rsaKey.php";

class Signature
{
    //sign
    public static function SignRequestData(string $clientPrivateKey,string $data): string
    {
        $signature = "";
        //使用私钥对数据进行签名
        openssl_sign($data, $signature, $clientPrivateKey, OPENSSL_ALGO_SHA512);
        // 输出签名
        return base64_encode($signature);
    }

    //sign
    public static function VerifyCallbackSign(string $payGatewayPublicKey,string $data, string $sign): bool
    {
        $signature = base64_decode($sign);
        $publicKeyId = openssl_pkey_get_public($payGatewayPublicKey);
        $verify = openssl_verify($data, $signature, $publicKeyId, OPENSSL_ALGO_SHA512);
        if ($verify == 1) {
            return true;
        } else {
            return false;
        }

        openssl_free_key($publicKeyId);
    }
}


