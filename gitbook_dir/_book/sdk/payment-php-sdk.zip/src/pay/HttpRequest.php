<?php
namespace Asen\Pay;
class HttpRequest
{
    private static $curl;

    protected static function init()
    {
        self::$curl = curl_init();
        curl_setopt(self::$curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt(self::$curl, CURLOPT_HEADER, false);
    }

    public static function get($url)
    {
        self::init();
        curl_setopt(self::$curl, CURLOPT_URL, $url);
        curl_setopt(self::$curl, CURLOPT_HTTPGET, true);
        return self::execute();
    }

    public static function post($url, $postData, $raw = false)
    {
        self::init();
        curl_setopt(self::$curl, CURLOPT_URL, $url);
        curl_setopt(self::$curl, CURLOPT_POST, true);

        if ($raw) {
            curl_setopt(self::$curl, CURLOPT_POSTFIELDS, $postData);
        } else {
            curl_setopt(self::$curl, CURLOPT_POSTFIELDS, http_build_query($postData));
        }

        return self::execute();
    }

    public static function setOption($option, $value)
    {
        curl_setopt(self::$curl, $option, $value);
    }

    public static function setHeaders($headers)
    {
        curl_setopt(self::$curl, CURLOPT_HTTPHEADER, $headers);
    }

    private static function execute()
    {
        $response = curl_exec(self::$curl);
        if (curl_errno(self::$curl)) {
            throw new \Exception(curl_error(self::$curl));
        }
        self::close();
        return $response;
    }

    private static function close()
    {
        curl_close(self::$curl);
    }
}