<?php
namespace Asen\Pay;

class RechargeResponse {
    //暂时可忽略 链类型
    public  string $address;
    public  int $code;

    public function CheckIsSuccess():bool
    {
        if($this->code == CodeSuccess){
            return true;
        }
        return false;
    }
    public static function newRechargeResponse(int $code,string $address): \Asen\Pay\RechargeResponse
    {
        $object = new RechargeResponse();
        $object->code = $code;
        $object->address = $address;
        return $object;
    }

}
