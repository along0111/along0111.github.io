<?php
require_once "vendor/autoload.php";
require_once "rsaKey.php";
use Asen\Pay\Signature;
$requestData = array("name" => "helloKitty");
//expect got signature: v+Ap38ZYT92X6cbTHhvCjGa2B4vNVQQKv6AeRMc6rKCjvh/4vAz7BHfS+EbAoZej1LpAv5X3wG+CLqCA5X1DjG3hrDG7xxqBJZIwEIlZMGWcNj5xjxYxcKcad8PI3Ch5VyA3ZIzaQDyisp3quLOagUfCugf8MkuaQO4oeBB0k+I=
echo Signature::SignRequestData(CLIENT_PRIVATE_KEY,json_encode($requestData, true))."\n";
//if result is true the signature is correct
var_dump(Signature::VerifyCallbackSign(PAY_GATEWAY_PUBLIC_KEY,json_encode($requestData, true),"fC6QtJRJlHQLnWDQFai1CneNNKGdXqtD+YbMYOYueGDed7TWuyf7HQtqLXi0vpK4cgJ7lEOMpIeWZKrDhratm5000Q7fip5ANSdWwGa1QJ3OiCGaX+Cfx5wGwX9wrLJvTXdmQ+D3bJ6OegGsriN/DVzz7bjVNKyKMjC5FiOm+wo="));

