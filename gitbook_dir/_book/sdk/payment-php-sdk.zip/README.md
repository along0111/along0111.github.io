##### 版本
`v1`

##### 使用方式
- 更改rsaKey.php中测试相应公私钥为实际公私钥

- 具体请参考 pay_test.php文件

```php
<?php
require_once "vendor/autoload.php";
require_once "rsaKey.php";
use Asen\Pay\Pay;

//请更改为实际的endpoint
$endPoint = "https://testpay.facai.dev/v1";
Pay::SetEndpoint("https://testpay.facai.dev/v1");
//appId
Pay::SetAppId(1003);
//apiKey
Pay::SetApiKey("api_key");
//plz change related const in rsaKey.php when you are in prod env
Pay::SetClientPrivateKeyAndPayGatewayPublicKey(CLIENT_PRIVATE_KEY,PAY_GATEWAY_PUBLIC_KEY);

//充值（获取充值地址）请求
$rechargeResp = Pay::RequestRecharge("9");
if ($rechargeResp->CheckIsSuccess()) {
    echo "got address success:" . $rechargeResp->address."\n";
} else {
    echo "got recharge address failed,error_code:" . $rechargeResp->code."\n";
}

//
//withdraw request
//$withdrawResp = Pay::RequestWithdraw("9", "goodtest5", "TUWtBt3EwuCAxfVW36V88fhhE6Vnak2mLU", 21.77);
//if ($withdrawResp->CheckIsSuccess()) {
//    //your successful business logical
//    echo "withdraw request success" . $withdrawResp->request_id;
//} else {
//    //商户可在此编写本地失败业务逻辑
//    echo "withdraw request failed, errorCode" . $withdrawResp->code;
//}
//
//
//充值回调
$rechargeCallbackRawData = '{"subject":"recharge_callback","signature":"XzVB5MewVRkQYI1W7ZCE8MCld+y9H8ss4Mvb7urvt6q2Xrt7ak850pd5dSL19tNoGHJa6htv1UJqAKRp+A+XTqTmepqVWphcaUZh4xoYvczEIY58MYsb9J8yFayAqT7l/mJojAgZLDRwdeGG+30p/uFykTUBGyox003QGjZinWM=","data":{"identify":"9","chain_type":3,"contract_type":32,"retry_id":"auto_1803074451005247488_8ebf5297cf03a55f89e8701eec8ee33a2f693a7e0cc69aa74376ea4cf87d43eb_9","order_id":"1803074451005247488","transaction_id":"8ebf5297cf03a55f89e8701eec8ee33a2f693a7e0cc69aa74376ea4cf87d43eb","amount":52}}';
$rechargeCallbackResult = Pay::RechargeCallback(true, $rechargeCallbackRawData);
//判断是否验签通过
if ($rechargeCallbackResult->checkSignature()) {
    //商户本地成功业务逻辑
    //response
    $rechargeCallbackResult->ResponseToPayGateWay();
//    echo "验证签名通过";
//    //可通过如下方式获取各个回调结果
//    echo $rechargeCallbackResult->amount;
//    echo $rechargeCallbackResult->transaction_id;
//    //也可通过以下方式获取回调数据array
//    var_dump($rechargeCallbackResult->GetOriginalData());
} else {
    //商户本地失败业务逻辑
    //failed response
    $rechargeCallbackResult->ResponseToPayGateWay();
    echo "非法回调";
}
//
//
//提现（代付）回调
$withdrawCallbackRawData = '{"subject":"withdraw_callback","signature":"tgAMalcVkggdp42JHo1u7TdqLvmE91acADSGCugJqhUnZ6hRtrP97AcUvlID0cmHTbXxhGiCj8cYv5ynqUiG5QYgZ9Y6umCgqvdKn90OdOVT7gxqJu3+VS2IL6S6pVLFxY2f2axM5c4tg+7sxatTxZKUP0rhn309BpM5vy296Gc=","data":{"identify":"9","chain_type":3,"contract_type":32,"order_id":"goodtest1","retry_id":"auto_goodtest1_351a805df2f0718b052e37c5338ec5e6c55807f35d382ddae1d5e57fd48de3dc_9","transaction_id":"351a805df2f0718b052e37c5338ec5e6c55807f35d382ddae1d5e57fd48de3dc","amount":21.77}}';
//var_dump(Pay::WithdrawCallback(true,$withdrawCallbackRawData));
$withdrawCallbackResult = Pay::WithdrawCallback(true, $withdrawCallbackRawData);
//判断是否验签通过
if ($withdrawCallbackResult->checkSignature()) {
    //商户本地成功业务逻辑
    //response
    $withdrawCallbackResult->ResponseToPayGateWay();
//    echo "提现回调验证签名通过";
//    //可通过如下方式获取各个回调结果
//    echo $withdrawCallbackResult->amount;
//    echo $withdrawCallbackResult->transaction_id;
//    //也可通过以下方式获取回调数据array
//    var_dump($withdrawCallbackResult->GetOriginalData());
} else {
    //商户本地失败业务逻辑
    //failed response
    $withdrawCallbackResult->ResponseToPayGateWay();
//    echo "非法回调";
}

```